/* ══════════════════════════════════════════
   game.js — Core game state & loop
   ══════════════════════════════════════════ */

const Game = (() => {
    const SIZE     = Maps.SIZE;
    const MOVE_MS  = 220;
    const MAX_POWER = 5;
    const GHOST_DUR = 5000;

    /* ── STATE ── */
    let S = {};          // game state object
    let loopTimer = null;
    let bossTimer  = null;

    /* ── INIT STATE ── */
    function buildState(saved) {
        const inv = Items.createInventory();
        if (saved && saved.inventory) {
            Object.entries(saved.inventory.slots || {}).forEach(([id, qty]) => {
                for (let i = 0; i < qty; i++) inv.add(id);
            });
        }

        const base = {
            mapIndex:       saved ? saved.mapIndex      : 0,
            floor:          saved ? saved.floor         : 1,
            catX:           saved ? saved.catX          : Maps.get(0).startX,
            catY:           saved ? saved.catY          : Maps.get(0).startY,
            direction:      null,
            lives:          saved ? saved.lives         : 3,
            hp:             saved ? saved.hp            : 100,
            maxHp:          saved ? saved.maxHp         : 100,
            score:          saved ? saved.score         : 0,
            coins:          saved ? saved.coins         : 0,
            power:          saved ? saved.power         : 0,
            abilityActive:  false,
            abilityTimeout: null,
            gameOver:       false,
            paused:         false,
            gameStarted:    false,
            bossSpawned:    false,
            bossDefeated:   false,
            playerFrozen:   false,
            frozenTimer:    null,
            inventory:      inv,
            equippedArmor:  saved ? saved.equippedArmor  : null,
            equippedWeapon: saved ? saved.equippedWeapon : null,
            enemies:        [],
            starX: 0, starY: 0,
            highScore:      Save.getHigh(),

            // helper exposed on state for item effects
            stunEnemies(ms) { Enemies.stunAll(S.enemies, ms); },
        };

        base.enemies = Enemies.spawnForMap(base.mapIndex, base.catX, base.catY);
        spawnStar(base);

        // Recalculate maxHp from equipped armor
        if (base.equippedArmor) {
            base.maxHp = Inventory.recalcMaxHp(base);
        }

        return base;
    }

    function spawnStar(state) {
        const map = Maps.get(state.mapIndex);
        let x, y, tries = 0;
        do {
            x = Math.floor(Math.random() * SIZE);
            y = Math.floor(Math.random() * SIZE);
            tries++;
        } while (
            tries < 200 && (
                Maps.isWall(state.mapIndex, x, y) ||
                (x === state.catX && y === state.catY) ||
                (x === map.portalX && y === map.portalY) ||
                (x === map.shopX   && y === map.shopY)   ||
                (x === map.healX   && y === map.healY)   ||
                state.enemies.some(e => e.x === x && e.y === y)
            )
        );
        state.starX = x;
        state.starY = y;
    }

    /* ── GAME OVER / DIE ── */
    function die() {
        // Check shield from armor
        if (S.equippedArmor) {
            const armorItem = Items.CATALOG[S.equippedArmor];
            if (armorItem && armorItem.stat && armorItem.stat.shield && armorItem.stat.shield > 0) {
                armorItem.stat.shield--;
                Audio.hurt();
                UI.flashBorder('red');
                if (armorItem.stat.shield <= 0) {
                    S.equippedArmor = null;
                    UI.toast('🛡 Shield broke!');
                }
                UI.updateHUD(S);
                return;
            }
        }

        S.hp -= 25;
        Audio.hurt();
        UI.flashBorder('red');

        if (S.hp <= 0) {
            S.lives--;
            S.hp = S.maxHp;
            UI.updateHUD(S);

            if (S.lives <= 0) {
                gameOver();
                return;
            }
            // Show "U DIED" disco for a life loss (not full game over)
            UI.showDeathScreen(false, () => {
                respawn();
            });
        }

        UI.updateHUD(S);
    }

    function respawn() {
        const map = Maps.get(S.mapIndex);
        S.catX      = map.startX;
        S.catY      = map.startY;
        S.direction = null;
        Boss.clear();
        S.bossSpawned = false;
        UI.flashBorder('red');
        UI.drawBoard(S);
    }

    function gameOver() {
        S.gameOver = true;
        stopBossTimer();

        if (S.score > S.highScore) {
            S.highScore = S.score;
            Save.setHigh(S.highScore);
        }

        Save.clear();

        // Show full game-over death screen, then prompt restart
        UI.showDeathScreen(true, () => {
            const again = confirm(
                `💀 GAME OVER!\n\nScore: ${S.score}\nHigh Score: ${S.highScore}\n\nPlay Again?`
            );
            if (again) newGame();
            else       showStart();
        });
    }

    /* ── GHOST ABILITY ── */
    function activateGhost() {
        if (S.power < MAX_POWER || S.abilityActive) return;
        S.power = 0;
        S.abilityActive = true;
        Audio.ghost();
        clearTimeout(S.abilityTimeout);
        S.abilityTimeout = setTimeout(() => {
            S.abilityActive = false;
            UI.updateHUD(S);
            UI.drawBoard(S);
        }, GHOST_DUR);
        UI.updateHUD(S);
    }

    /* ── MAP TRANSITION ── */
    function nextMap() {
        const next = S.mapIndex + 1;
        Audio.portal();
        Boss.clear();
        S.bossSpawned  = false;
        S.bossDefeated = false;
        stopBossTimer();

        if (next >= Maps.count()) {
            // Victory!
            Save.clear();
            S.gameOver = true;
            alert(`🎉 YOU WIN!\n\nYou conquered all ${Maps.count()} maps!\nFinal Score: ${S.score}\n\nCongratulations!`);
            showStart();
            return;
        }

        S.mapIndex  = next;
        S.floor++;
        const map   = Maps.get(next);
        S.catX      = map.startX;
        S.catY      = map.startY;
        S.direction = null;
        S.enemies   = Enemies.spawnForMap(next, S.catX, S.catY);
        spawnStar(S);

        UI.showMapTransition(map, () => {
            UI.updateHUD(S);
            UI.drawBoard(S);
        });
    }

    /* ── BOSS SPAWNING ── */
    function startBossTimer() {
        const boss = Boss.spawn(S.mapIndex);
        if (!boss) return;

        S.bossSpawned = true;
        document.getElementById('bossHudWrap').classList.remove('hidden');
        UI.updateBossHud(boss);
        Audio.boss();

        // Show intro overlay
        UI.showBossIntro(boss, () => {
            bossTimer = setInterval(() => {
                if (!S.gameStarted || S.paused || S.gameOver) return;
                Boss.tick(
                    S.mapIndex,
                    S.catX, S.catY,
                    // onFreeze callback
                    ms => {
                        if (!S.playerFrozen) {
                            S.playerFrozen = true;
                            UI.toast('❄️ Frozen!');
                            clearTimeout(S.frozenTimer);
                            S.frozenTimer = setTimeout(() => { S.playerFrozen = false; }, ms);
                        }
                    },
                    // onSplitSpawn callback
                    () => {
                        Enemies.addEnemy(S.mapIndex, S.catX, S.catY, S.enemies);
                        UI.toast('👑 The Shadow King splits!');
                    }
                );
                checkBossCollision();
                UI.drawBoard(S);
            }, Boss.current() ? Boss.current().speed : 200);
        });
    }

    function stopBossTimer() {
        clearInterval(bossTimer);
        bossTimer = null;
        document.getElementById('bossHudWrap').classList.add('hidden');
    }

    function checkBossCollision() {
        const boss = Boss.current();
        if (!boss) return;
        if (boss.x === S.catX && boss.y === S.catY) {
            if (!S.abilityActive) die();
        }
        // Weapon attack: if player is adjacent and has a weapon
        if (S.equippedWeapon) {
            const w = Items.CATALOG[S.equippedWeapon];
            if (w && w.stat && w.stat.attack) {
                const dist = Math.abs(boss.x - S.catX) + Math.abs(boss.y - S.catY);
                if (dist <= 1) {
                    const killed = Boss.damage(w.stat.attack);
                    UI.updateBossHud(Boss.current());
                    if (killed) bossKilled();
                }
            }
        }
    }

    function bossKilled() {
        stopBossTimer();
        S.bossDefeated = true;
        S.coins += Boss.current().reward;
        const reward = Boss.current().reward;
        Boss.clear();
        Audio.levelUp();
        UI.toast(`👑 BOSS DEFEATED! +${reward} 🪙`);
        UI.updateHUD(S);
        UI.drawBoard(S);
    }

    /* ── MAIN GAME TICK ── */
    function tick() {
        if (!S.gameStarted || S.paused || S.gameOver) return;
        if (S.direction === null) return;
        if (S.playerFrozen) return;

        let nx = S.catX, ny = S.catY;
        if (S.direction === 'up')    ny--;
        if (S.direction === 'down')  ny++;
        if (S.direction === 'left')  nx--;
        if (S.direction === 'right') nx++;

        // Edge
        if (nx < 0 || nx >= SIZE || ny < 0 || ny >= SIZE) { die(); return; }

        // Wall (ghost passes through)
        if (!S.abilityActive && Maps.isWall(S.mapIndex, nx, ny)) { die(); return; }

        // Lava trail
        if (!S.abilityActive && Boss.isTrailCell(nx, ny)) { die(); return; }

        S.catX = nx;
        S.catY = ny;

        Enemies.moveAll(S.mapIndex, S.enemies, S.catX, S.catY);

        // Enemy collision
        if (!S.abilityActive) {
            if (Enemies.at(S.enemies, S.catX, S.catY)) die();
        }

        const map = Maps.get(S.mapIndex);

        // Portal
        if (S.catX === map.portalX && S.catY === map.portalY) {
            nextMap();
            return;
        }

        // Shop
        if (S.catX === map.shopX && S.catY === map.shopY) {
            S.paused = true;
            Shop.open(S);
        }

        // Heal shrine
        if (S.catX === map.healX && S.catY === map.healY && S.hp < S.maxHp) {
            const healed = Math.min(30, S.maxHp - S.hp);
            S.hp += healed;
            Audio.heal();
            UI.toast(`💖 Healed +${healed} HP`);
        }

        // Star
        if (S.catX === S.starX && S.catY === S.starY) {
            collectStar();
        }

        if (S.gameOver) return;
        UI.drawBoard(S);
        UI.updateHUD(S);
    }

    function collectStar() {
        S.score++;
        S.coins++;
        if (S.score > S.highScore) { S.highScore = S.score; Save.setHigh(S.highScore); }
        if (S.power < MAX_POWER) S.power++;
        Audio.coin();

        // Drop item?
        const drop = Items.randomDrop(S.mapIndex);
        if (drop) {
            S.inventory.add(drop);
            const it = Items.CATALOG[drop];
            UI.toast(`Dropped: ${it.emoji} ${it.name}!`);
        }

        // Score milestones: add enemy
        if ([5, 10, 15, 20, 25].includes(S.score)) {
            Enemies.addEnemy(S.mapIndex, S.catX, S.catY, S.enemies);
        }

        // Trigger boss
        const mapDef = Maps.get(S.mapIndex);
        if (!S.bossSpawned && S.score >= mapDef.bossAt) {
            startBossTimer();
        }

        spawnStar(S);
    }

    /* ── INPUT ── */
    function setDirection(dir) {
        if (!S.gameStarted || S.paused || S.gameOver) return;
        S.direction = dir;
    }

    /* ── FLOW ── */
    function newGame(saved) {
        if (loopTimer) clearInterval(loopTimer);
        stopBossTimer();
        Boss.clear();
        S = buildState(saved || null);
        S.gameStarted = true;
        UI.updateHUD(S);
        UI.drawBoard(S);
        loopTimer = setInterval(tick, MOVE_MS);
    }

    function showStart() {
        if (loopTimer) clearInterval(loopTimer);
        stopBossTimer();
        S.gameStarted = false;
        document.getElementById('startMenu').classList.remove('hidden');
    }

    function pause() {
        S.paused = !S.paused;
        document.getElementById('pauseMenu').classList.toggle('hidden');
    }

    function saveGame() {
        const ts = Save.save(S);
        Audio.save();
        UI.toast(`💾 Saved! ${Save.formatDate(ts)}`);
    }

    function loadGame() {
        const saved = Save.load();
        if (!saved) return false;
        newGame(saved);
        return true;
    }

    function getState() { return S; }

    return {
        newGame, loadGame, saveGame, showStart,
        pause, setDirection, activateGhost,
        getState,
    };
})();
