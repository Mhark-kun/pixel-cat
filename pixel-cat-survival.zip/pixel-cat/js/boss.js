/* ══════════════════════════════════════════
   boss.js — Boss definitions & battle logic
   ══════════════════════════════════════════ */

const Boss = (() => {
    const SIZE = Maps.SIZE;

    /* ── BOSS DEFINITIONS (one per map) ── */
    const BOSSES = [
        {
            mapIndex: 0,
            name: 'DUNGEON WRAITH',
            emoji: '👺',
            desc: 'An ancient spirit with a taste for lost cats. It moves fast and hits hard.',
            hp: 8, maxHp: 8,
            speed: 160,          // ms between moves
            reward: 40,          // coins on kill
            pattern: 'chase',    // always chases
        },
        {
            mapIndex: 1,
            name: 'FOREST SPECTER',
            emoji: '🌿',
            desc: 'A cursed guardian of the old woods. Teleports to cut off your escape.',
            hp: 12, maxHp: 12,
            speed: 200,
            reward: 60,
            pattern: 'teleport',  // occasionally teleports
        },
        {
            mapIndex: 2,
            name: 'LAVA TITAN',
            emoji: '🔥',
            desc: 'Born from the molten core. Leaves burning trails that block your path.',
            hp: 16, maxHp: 16,
            speed: 280,           // slower but has trail
            reward: 80,
            pattern: 'trail',
        },
        {
            mapIndex: 3,
            name: 'FROST LICH',
            emoji: '❄️',
            desc: 'Master of ice. Slows the player and summons ice shards.',
            hp: 20, maxHp: 20,
            speed: 220,
            reward: 100,
            pattern: 'freeze',    // freezes player occasionally
        },
        {
            mapIndex: 4,
            name: 'SHADOW KING',
            emoji: '👑',
            desc: 'The final ruler of darkness. Splits into two on low HP.',
            hp: 30, maxHp: 30,
            speed: 160,
            reward: 200,
            pattern: 'split',
        },
    ];

    let activeBoss    = null;
    let bossInterval  = null;
    let trailCells    = [];   // for lava trail pattern
    let frozenPlayer  = false;
    let frozenTimer   = null;
    let splitDone     = false;

    function get(mapIndex) {
        return BOSSES.find(b => b.mapIndex === mapIndex) || null;
    }

    /** Spawn the boss for the given map */
    function spawn(mapIndex) {
        const def = get(mapIndex);
        if (!def) return null;
        activeBoss = {
            ...def,
            x: 0, y: 0,
            hp: def.hp, maxHp: def.maxHp,
        };
        trailCells  = [];
        frozenPlayer = false;
        splitDone   = false;
        return activeBoss;
    }

    function isActive() { return activeBoss !== null; }
    function current()  { return activeBoss; }

    /** Despawn / clear boss state */
    function clear() {
        clearInterval(bossInterval);
        activeBoss   = null;
        trailCells   = [];
        frozenPlayer = false;
    }

    /** Check if player is on a trail cell */
    function isTrailCell(x, y) {
        return trailCells.some(c => c.x === x && c.y === y);
    }

    /** Called every boss tick — returns special flags */
    function tick(mapIndex, catX, catY, onFreeze, onSplitSpawn) {
        if (!activeBoss) return;
        const boss = activeBoss;
        const dx   = catX - boss.x;
        const dy   = catY - boss.y;

        // Record last position for trail
        const lastX = boss.x, lastY = boss.y;

        // Movement
        const tryMove = (nx, ny) => {
            if (nx < 0 || nx >= SIZE || ny < 0 || ny >= SIZE) return false;
            if (Maps.isWall(mapIndex, nx, ny)) return false;
            boss.x = nx; boss.y = ny;
            return true;
        };

        if (boss.pattern === 'teleport' && Math.random() < 0.15) {
            // Teleport to a random adjacent quadrant cell near player
            const tx = Math.max(0, Math.min(SIZE-1, catX + (Math.random()<0.5?-3:3)));
            const ty = Math.max(0, Math.min(SIZE-1, catY + (Math.random()<0.5?-3:3)));
            if (!Maps.isWall(mapIndex, tx, ty)) { boss.x = tx; boss.y = ty; }
        } else {
            if (Math.abs(dx) > Math.abs(dy)) {
                if (!tryMove(boss.x + (dx>0?1:-1), boss.y))
                    tryMove(boss.x, boss.y + (dy>0?1:-1));
            } else {
                if (!tryMove(boss.x, boss.y + (dy>0?1:-1)))
                    tryMove(boss.x + (dx>0?1:-1), boss.y);
            }
        }

        // Trail pattern: mark cell
        if (boss.pattern === 'trail') {
            trailCells.push({ x: lastX, y: lastY, ttl: 6 });
            // Decay trail
            trailCells = trailCells
                .map(c => ({ ...c, ttl: c.ttl - 1 }))
                .filter(c => c.ttl > 0);
        }

        // Freeze pattern
        if (boss.pattern === 'freeze' && Math.random() < 0.10 && !frozenPlayer) {
            frozenPlayer = true;
            if (onFreeze) onFreeze(1500);
            clearTimeout(frozenTimer);
            frozenTimer = setTimeout(() => { frozenPlayer = false; }, 1500);
        }

        // Split pattern: when hp <= 30%, spawn a clone enemy
        if (boss.pattern === 'split' && !splitDone && boss.hp <= Math.ceil(boss.maxHp * 0.3)) {
            splitDone = true;
            if (onSplitSpawn) onSplitSpawn();
        }
    }

    /** Deal damage to boss; returns true if boss defeated */
    function damage(dmg) {
        if (!activeBoss) return false;
        activeBoss.hp -= dmg;
        return activeBoss.hp <= 0;
    }

    function isFrozen() { return frozenPlayer; }

    return { get, spawn, isActive, current, clear, tick,
             damage, isTrailCell, isFrozen, trailCells };
})();
