/* ══════════════════════════════════════════
   save.js — Save / Load system
   ══════════════════════════════════════════ */

const Save = (() => {
    const KEY    = 'pixelCatSave_v3';
    const HI_KEY = 'pixelCatHS_v3';

    /** Returns true if a save slot exists */
    function exists() {
        return !!localStorage.getItem(KEY);
    }

    /** Save current game state */
    function save(state) {
        const snapshot = {
            ts:           Date.now(),
            mapIndex:     state.mapIndex,
            floor:        state.floor,
            catX:         state.catX,
            catY:         state.catY,
            lives:        state.lives,
            hp:           state.hp,
            maxHp:        state.maxHp,
            score:        state.score,
            coins:        state.coins,
            power:        state.power,
            inventory:    JSON.parse(JSON.stringify(state.inventory)),
            equippedArmor:state.equippedArmor,
            equippedWeapon:state.equippedWeapon,
            // enemies are re-spawned on load to avoid stale positions
        };
        localStorage.setItem(KEY, JSON.stringify(snapshot));
        return snapshot.ts;
    }

    /** Load and return saved state, or null */
    function load() {
        const raw = localStorage.getItem(KEY);
        if (!raw) return null;
        try   { return JSON.parse(raw); }
        catch { return null; }
    }

    /** Delete the save slot */
    function clear() {
        localStorage.removeItem(KEY);
    }

    /** High score helpers */
    function getHigh() {
        return parseInt(localStorage.getItem(HI_KEY) || '0', 10);
    }

    function setHigh(score) {
        localStorage.setItem(HI_KEY, score);
    }

    /** Human-readable timestamp */
    function formatDate(ts) {
        if (!ts) return '';
        const d = new Date(ts);
        return d.toLocaleDateString() + ' ' + d.toLocaleTimeString();
    }

    return { exists, save, load, clear, getHigh, setHigh, formatDate };
})();
