/* ══════════════════════════════════════════
   shop.js — Shop overlay logic
   ══════════════════════════════════════════ */

const Shop = (() => {
    let _state = null;  // reference to game state

    function open(state) {
        _state = state;
        render();
        document.getElementById('shopMenu').classList.remove('hidden');
    }

    function close() {
        document.getElementById('shopMenu').classList.add('hidden');
    }

    function render() {
        const stock = Items.shopStock(_state.mapIndex);
        const grid  = document.getElementById('shopGrid');
        document.getElementById('shopCoins').textContent = `🪙 ${_state.coins}`;
        grid.innerHTML = '';

        stock.forEach(item => {
            const canAfford = _state.coins >= item.price;
            const card = document.createElement('div');
            card.className = 'item-card' + (canAfford ? '' : ' cant-afford');

            card.innerHTML = `
                <div class="ic-emoji">${item.emoji}</div>
                <div class="ic-name">${item.name}</div>
                <div class="ic-desc">${item.desc}</div>
                <div class="ic-price">🪙 ${item.price}</div>
            `;

            if (canAfford) {
                card.addEventListener('click', () => buy(item));
            }

            grid.appendChild(card);
        });
    }

    function buy(item) {
        if (!_state || _state.coins < item.price) return;
        _state.coins -= item.price;
        _state.inventory.add(item.id);
        Audio.buy();
        UI.toast(`Bought ${item.emoji} ${item.name}!`);
        render();  // refresh prices / afford state
        UI.updateHUD(_state);
    }

    return { open, close, render };
})();
