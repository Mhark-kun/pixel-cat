/* ══════════════════════════════════════════
   maps.js — All map definitions
   Each map has: name, flavour, theme,
   walls[], startX/Y, portalX/Y,
   shopX/Y, healX/Y, enemy config
   ══════════════════════════════════════════ */

const Maps = (() => {

    const SIZE = 16;

    const MAPS = [
        /* ── MAP 0: THE DUNGEON ── */
        {
            name:    'THE DUNGEON',
            flavour: 'Cold stone, distant drips. Something stirs in the dark.',
            theme:   'dungeon',
            wallClass: 'wall',
            tileClass: 'tile-dungeon',
            startX: 8, startY: 8,
            portalX: 14, portalY: 14,
            shopX: 1, shopY: 14,
            healX: 14, healY: 1,
            walls: [
                {x:4,y:4},{x:4,y:5},{x:4,y:6},
                {x:10,y:8},{x:11,y:8},{x:12,y:8},
                {x:7,y:12},{x:8,y:12},{x:9,y:12},
                {x:2,y:10},{x:3,y:10},{x:4,y:10},
                {x:12,y:2},{x:13,y:2},{x:12,y:3},
            ],
            enemyConfig: { count:2, speed:220, chaseRange:16 },
            bossAt: 8,
        },

        /* ── MAP 1: HAUNTED FOREST ── */
        {
            name:    'HAUNTED FOREST',
            flavour: 'Ancient trees groan. Eyes watch from every shadow.',
            theme:   'forest',
            wallClass: 'wall-forest',
            tileClass: 'tile-forest',
            startX: 1, startY: 1,
            portalX: 14, portalY: 14,
            shopX: 7, shopY: 0,
            healX: 0, healY: 14,
            walls: [
                {x:2,y:2},{x:3,y:2},{x:2,y:3},
                {x:6,y:5},{x:6,y:6},{x:6,y:7},{x:7,y:5},{x:8,y:5},
                {x:10,y:2},{x:11,y:2},{x:10,y:3},
                {x:3,y:10},{x:4,y:10},{x:5,y:10},{x:3,y:11},
                {x:12,y:9},{x:13,y:9},{x:12,y:10},{x:12,y:11},
                {x:8,y:13},{x:9,y:13},{x:10,y:13},
            ],
            enemyConfig: { count:3, speed:200, chaseRange:14 },
            bossAt: 10,
        },

        /* ── MAP 2: LAVA KINGDOM ── */
        {
            name:    'LAVA KINGDOM',
            flavour: 'The ground smoulders. One wrong step and you\'re ash.',
            theme:   'lava',
            wallClass: 'wall-lava',
            tileClass: 'tile-lava',
            startX: 1, startY: 7,
            portalX: 14, portalY: 8,
            shopX: 8, shopY: 0,
            healX: 8, healY: 15,
            walls: [
                {x:4,y:0},{x:4,y:1},{x:4,y:2},{x:5,y:2},
                {x:4,y:6},{x:4,y:7},{x:4,y:8},{x:4,y:9},
                {x:8,y:4},{x:8,y:5},{x:9,y:4},{x:10,y:4},
                {x:8,y:10},{x:8,y:11},{x:9,y:11},{x:10,y:11},
                {x:11,y:6},{x:11,y:7},{x:11,y:8},{x:12,y:7},
                {x:3,y:13},{x:4,y:13},{x:5,y:13},{x:4,y:14},
            ],
            enemyConfig: { count:3, speed:190, chaseRange:16 },
            bossAt: 12,
        },

        /* ── MAP 3: FROZEN TUNDRA ── */
        {
            name:    'FROZEN TUNDRA',
            flavour: 'Every breath fogs. The frost seeps into your bones.',
            theme:   'ice',
            wallClass: 'wall-ice',
            tileClass: 'tile-ice',
            startX: 8, startY: 0,
            portalX: 8, portalY: 15,
            shopX: 0, shopY: 8,
            healX: 15, healY: 8,
            walls: [
                {x:1,y:3},{x:2,y:3},{x:3,y:3},{x:1,y:4},
                {x:6,y:1},{x:7,y:1},{x:8,y:1},{x:9,y:1},{x:10,y:1},
                {x:5,y:6},{x:6,y:6},{x:5,y:7},{x:5,y:8},
                {x:10,y:6},{x:11,y:6},{x:10,y:7},{x:10,y:8},
                {x:1,y:11},{x:2,y:11},{x:3,y:11},{x:1,y:12},{x:2,y:12},
                {x:12,y:11},{x:13,y:11},{x:14,y:11},{x:13,y:12},
                {x:6,y:14},{x:7,y:14},{x:8,y:14},{x:9,y:14},{x:10,y:14},
            ],
            enemyConfig: { count:4, speed:240, chaseRange:12 },
            bossAt: 14,
        },

        /* ── MAP 4: SHADOW CASTLE (FINAL) ── */
        {
            name:    'SHADOW CASTLE',
            flavour: 'The final stronghold. Victory or oblivion — nothing between.',
            theme:   'castle',
            wallClass: 'wall-castle',
            tileClass: 'tile-castle',
            startX: 8, startY: 15,
            portalX: 8, portalY: 0,   // victory portal
            shopX: 0, shopY: 0,
            healX: 15, healY: 15,
            walls: [
                {x:0,y:4},{x:1,y:4},{x:2,y:4},
                {x:5,y:2},{x:6,y:2},{x:7,y:2},
                {x:9,y:2},{x:10,y:2},{x:11,y:2},
                {x:13,y:4},{x:14,y:4},{x:15,y:4},
                {x:3,y:7},{x:4,y:7},{x:3,y:8},{x:4,y:8},
                {x:11,y:7},{x:12,y:7},{x:11,y:8},{x:12,y:8},
                {x:0,y:11},{x:1,y:11},{x:2,y:11},
                {x:5,y:13},{x:6,y:13},
                {x:9,y:13},{x:10,y:13},
                {x:13,y:11},{x:14,y:11},{x:15,y:11},
                {x:7,y:7},{x:8,y:7},{x:7,y:8},{x:8,y:8},{x:9,y:7},{x:9,y:8},
            ],
            enemyConfig: { count:5, speed:175, chaseRange:16 },
            bossAt: 10,  // boss triggers earlier on final map
            isFinal: true,
        },
    ];

    function get(index) {
        return MAPS[index] || MAPS[0];
    }

    function count() { return MAPS.length; }

    function isWall(mapIndex, x, y) {
        const m = get(mapIndex);
        return m.walls.some(w => w.x === x && w.y === y);
    }

    return { get, count, isWall, SIZE };
})();
