/* ══════════════════════════════════════════
   inventory.js — Inventory overlay & use
   ══════════════════════════════════════════ */

const Inventory = (() => {
    let _state = null;

    function open(state) {
        _state = state;
        render();
        document.getElementById('inventoryMenu').classList.remove('hidden');
    }

    function close() {
        document.getElementById('inventoryMenu').classList.add('hidden');
    }

    function render() {
        const grid = document.getElementById('inventoryGrid');
        grid.innerHTML = '';

        const items = _state.inventory.list();

        if (items.length === 0) {
            grid.innerHTML = '<p style="color:#445566;font-size:0.85rem;padding:20px;grid-column:1/-1">Your inventory is empty.<br>Collect ⭐ stars or visit 🏪 the shop!</p>';
        } else {
            items.forEach(item => {
                const isEquipped = (
                    (item.type === 'armor'  && _state.equippedArmor   === item.id) ||
                    (item.type === 'weapon' && _state.equippedWeapon  === item.id)
                );
                const card = document.createElement('div');
                card.className = 'item-card' + (isEquipped ? ' equipped' : '');

                let badgeText = '';
                if (item.type === 'consumable') badgeText = 'USE';
                else if (item.type === 'armor')  badgeText = isEquipped ? 'EQUIPPED' : 'EQUIP';
                else if (item.type === 'weapon') badgeText = isEquipped ? 'EQUIPPED' : 'EQUIP';

                card.innerHTML = `
                    <div class="ic-emoji">${item.emoji}</div>
                    <div class="ic-name">${item.name}</div>
                    <div class="ic-desc">${item.desc}</div>
                    <div class="ic-qty">x${item.qty}</div>
                    <div class="ic-badge">${badgeText}</div>
                `;

                card.addEventListener('click', () => useOrEquip(item));
                grid.appendChild(card);
            });
        }

        // Stat panel
        renderStats();
    }

    function renderStats() {
        const s = _state;
        const panel = document.getElementById('statPanel');
        const armorItem  = s.equippedArmor  ? Items.CATALOG[s.equippedArmor]  : null;
        const weaponItem = s.equippedWeapon ? Items.CATALOG[s.equippedWeapon] : null;

        panel.innerHTML = `
            <div>❤️ Lives</div>       <div><span>${s.lives}</span></div>
            <div>💖 HP</div>          <div><span>${s.hp} / ${s.maxHp}</span></div>
            <div>⭐ Score</div>       <div><span>${s.score}</span></div>
            <div>🪙 Coins</div>       <div><span>${s.coins}</span></div>
            <div>🛡 Armor</div>        <div><span>${armorItem ? armorItem.emoji + ' ' + armorItem.name : 'None'}</span></div>
            <div>⚔️ Weapon</div>      <div><span>${weaponItem ? weaponItem.emoji + ' ' + weaponItem.name : 'None'}</span></div>
        `;
    }

    function useOrEquip(item) {
        if (!_state) return;

        if (item.type === 'consumable') {
            if (!_state.inventory.has(item.id)) return;
            item.effect(_state);
            _state.inventory.remove(item.id);
            Audio.heal();
            UI.toast(`Used ${item.emoji} ${item.name}!`);
        } else if (item.type === 'armor') {
            if (_state.equippedArmor === item.id) {
                // Unequip
                _state.equippedArmor = null;
                _state.maxHp = recalcMaxHp(_state);
                _state.hp    = Math.min(_state.hp, _state.maxHp);
            } else {
                _state.equippedArmor = item.id;
                _state.maxHp = recalcMaxHp(_state);
            }
            UI.toast(`${item.emoji} ${item.name} ${_state.equippedArmor === item.id ? 'equipped' : 'unequipped'}!`);
        } else if (item.type === 'weapon') {
            if (_state.equippedWeapon === item.id) {
                _state.equippedWeapon = null;
            } else {
                _state.equippedWeapon = item.id;
            }
            UI.toast(`${item.emoji} ${item.name} ${_state.equippedWeapon === item.id ? 'equipped' : 'unequipped'}!`);
        }

        UI.updateHUD(_state);
        render();
    }

    /** Recalculate maxHp from base + armor bonus */
    function recalcMaxHp(state) {
        let base = 100;
        if (state.equippedArmor) {
            const a = Items.CATALOG[state.equippedArmor];
            if (a && a.stat && a.stat.maxHp) base += a.stat.maxHp;
        }
        return base;
    }

    /** Use first consumable in inventory (for quick-use key / mobile btn) */
    function quickUse(state) {
        const consumables = state.inventory.list().filter(i => i.type === 'consumable');
        if (consumables.length === 0) { UI.toast('No consumables!'); return; }
        const item = consumables[0];
        item.effect(state);
        state.inventory.remove(item.id);
        Audio.heal();
        UI.toast(`Used ${item.emoji} ${item.name}!`);
        UI.updateHUD(state);
    }

    return { open, close, render, useOrEquip, quickUse, recalcMaxHp };
})();
