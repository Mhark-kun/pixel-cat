/* ══════════════════════════════════════════
   ui.js — All rendering & overlay helpers
   ══════════════════════════════════════════ */

const UI = (() => {
    const board     = document.getElementById('gameBoard');
    const powerBar  = document.getElementById('powerBar');
    const toastEl   = document.getElementById('toast');

    let toastTimer  = null;
    let flashTimer  = null;

    /* ── TOAST ── */
    function toast(msg, duration = 2000) {
        toastEl.textContent = msg;
        toastEl.classList.remove('hidden');
        clearTimeout(toastTimer);
        toastTimer = setTimeout(() => toastEl.classList.add('hidden'), duration);
    }

    /* ── BORDER FLASH ── */
    function flashBorder(color) {
        const c = color === 'red' ? '#ff3355' : '#44ffcc';
        board.style.borderColor = c;
        clearTimeout(flashTimer);
        flashTimer = setTimeout(() => { board.style.borderColor = ''; }, 350);
    }

    /* ── HUD ── */
    function updateHUD(S) {
        document.getElementById('hudLives').textContent   = S.lives;
        document.getElementById('hudScore').textContent   = S.score;
        document.getElementById('hudCoins').textContent   = S.coins;
        document.getElementById('hudHi').textContent      = S.highScore;
        document.getElementById('hudEnemies').textContent = S.enemies.length + (Boss.isActive() ? '+👑' : '');
        document.getElementById('hudMap').textContent     = '🗺 ' + Maps.get(S.mapIndex).name;
        document.getElementById('hudFloor').textContent   = 'Floor ' + S.floor;

        // HP bar
        const hpPct = Math.max(0, (S.hp / S.maxHp) * 100);
        document.getElementById('hpBar').style.width = hpPct + '%';
        document.getElementById('hudHp').textContent  = S.hp;

        // Power bar
        powerBar.style.width = ((S.power / 5) * 100) + '%';

        // Ability badge
        const badge = document.getElementById('abilityBadge');
        if (S.abilityActive) {
            badge.textContent = '👻 ACTIVE';
            badge.className   = 'ability-badge active';
        } else if (S.power >= 5) {
            badge.textContent = '👻 READY';
            badge.className   = 'ability-badge ready';
        } else {
            badge.textContent = `GHOST ${S.power}/5`;
            badge.className   = 'ability-badge';
        }

        // Mobile ghost btn
        const gb = document.getElementById('ghostBtn');
        if (gb) {
            gb.classList.toggle('powered', S.power >= 5 && !S.abilityActive);
        }

        // Item bar (quick slots)
        renderItemBar(S);
    }

    function renderItemBar(S) {
        const bar   = document.getElementById('itemBar');
        const items = S.inventory.list().slice(0, 5);
        bar.innerHTML = '';
        items.forEach(item => {
            const slot = document.createElement('div');
            slot.className = 'item-slot';
            slot.title     = item.name;
            slot.textContent = item.emoji;
            if (item.qty > 1) {
                const qty = document.createElement('span');
                qty.className   = 'slot-qty';
                qty.textContent = item.qty;
                slot.appendChild(qty);
            }
            slot.addEventListener('click', () => {
                if (item.type === 'consumable') {
                    item.effect(Game.getState());
                    Game.getState().inventory.remove(item.id);
                    Audio.heal();
                    toast(`Used ${item.emoji}!`);
                    updateHUD(Game.getState());
                    drawBoard(Game.getState());
                }
            });
            bar.appendChild(slot);
        });
    }

    /* ── BOSS HUD ── */
    function updateBossHud(boss) {
        if (!boss) return;
        const pct = Math.max(0, (boss.hp / boss.maxHp) * 100);
        document.getElementById('bossHpBar').style.width = pct + '%';
        document.getElementById('bossHudName').textContent = boss.emoji + ' ' + boss.name;
        document.getElementById('bossHudHp').textContent   = boss.hp;
    }

    /* ── MAP TRANSITION ── */
    function showMapTransition(map, cb) {
        const el = document.getElementById('mapTransition');
        document.getElementById('mapName').textContent    = map.name;
        document.getElementById('mapFlavour').textContent = map.flavour;
        el.classList.remove('hidden');
        Audio.portal();
        setTimeout(() => {
            el.classList.add('hidden');
            if (cb) cb();
        }, 2200);
    }

    /* ── BOSS INTRO ── */
    function showBossIntro(boss, cb) {
        document.getElementById('bossName').textContent = boss.emoji + ' ' + boss.name;
        document.getElementById('bossDesc').textContent = boss.desc;
        const el  = document.getElementById('bossIntro');
        const btn = document.getElementById('btnBossOk');
        el.classList.remove('hidden');

        const handler = () => {
            el.classList.add('hidden');
            btn.removeEventListener('click', handler);
            if (cb) cb();
        };
        btn.addEventListener('click', handler);
    }

    /* ── BOARD DRAW ── */
    function drawBoard(S) {
        const mapDef  = Maps.get(S.mapIndex);
        const boss    = Boss.current();
        const wallSet = new Set(mapDef.walls.map(w => `${w.x},${w.y}`));

        board.innerHTML = '';

        for (let y = 0; y < Maps.SIZE; y++) {
            for (let x = 0; x < Maps.SIZE; x++) {
                const cell  = document.createElement('div');
                const key   = `${x},${y}`;
                const classes = ['cell', mapDef.tileClass];

                // Wall
                if (wallSet.has(key)) {
                    classes.push(mapDef.wallClass);
                    cell.className = classes.join(' ');
                    board.appendChild(cell);
                    continue;
                }

                // Portal
                if (x === mapDef.portalX && y === mapDef.portalY) {
                    classes.push('cell-portal');
                    cell.textContent = S.bossDefeated ? '🌀' : '🚪';
                    cell.className = classes.join(' ');
                    board.appendChild(cell);
                    continue;
                }

                // Shop
                if (x === mapDef.shopX && y === mapDef.shopY) {
                    classes.push('cell-shop');
                    cell.textContent = '🏪';
                    cell.className = classes.join(' ');
                    board.appendChild(cell);
                    continue;
                }

                // Heal shrine
                if (x === mapDef.healX && y === mapDef.healY) {
                    classes.push('cell-heal');
                    cell.textContent = '💖';
                    cell.className = classes.join(' ');
                    board.appendChild(cell);
                    continue;
                }

                // Boss
                if (boss && boss.x === x && boss.y === y) {
                    classes.push('cell-boss');
                    cell.textContent = boss.emoji;
                    cell.className = classes.join(' ');
                    board.appendChild(cell);
                    continue;
                }

                // Lava trail
                if (Boss.isTrailCell(x, y)) {
                    cell.textContent = '🔥';
                    classes.push('cell-enemy');
                    cell.className = classes.join(' ');
                    board.appendChild(cell);
                    continue;
                }

                // Enemy
                const enemy = Enemies.at(S.enemies, x, y);
                if (enemy) {
                    classes.push('cell-enemy');
                    cell.textContent = enemy.stunned ? '💫' : '😾';
                    cell.className = classes.join(' ');
                    board.appendChild(cell);
                    continue;
                }

                // Star
                if (x === S.starX && y === S.starY) {
                    classes.push('cell-star');
                    cell.textContent = '⭐';
                    cell.className = classes.join(' ');
                    board.appendChild(cell);
                    continue;
                }

                // Player
                if (x === S.catX && y === S.catY) {
                    if (S.abilityActive)    classes.push('cell-ghost');
                    else                    classes.push('cell-player');
                    cell.textContent = S.abilityActive ? '👻' : (S.playerFrozen ? '🥶' : '🐱');
                    cell.className = classes.join(' ');
                    board.appendChild(cell);
                    continue;
                }

                cell.className = classes.join(' ');
                board.appendChild(cell);
            }
        }
    }

    /* ── DEATH SCREEN ── */
    let _deathMusicTimer = null;

    function showDeathScreen(isGameOver, onDone) {
        const el        = document.getElementById('deathScreen');
        const titleEl   = document.getElementById('deathTitle');
        const subEl     = document.getElementById('deathSub');
        const livesEl   = document.getElementById('deathLives');
        const btn       = document.getElementById('btnDeathContinue');
        const lightsEl  = document.getElementById('discoLights');
        const music     = document.getElementById('caramelMusic');

        // Text content
        titleEl.textContent = isGameOver ? 'GAME OVER' : 'U DIED';
        subEl.textContent   = isGameOver
            ? '— NO MORE LIVES —'
            : 'SKILL ISSUE DETECTED';

        const S = Game.getState();
        livesEl.textContent = isGameOver
            ? `Final Score: ${S.score}`
            : `❤️ Lives remaining: ${S.lives}`;

        btn.textContent = isGameOver ? '▶ CONTINUE' : '▶ TRY AGAIN';

        // Build disco beams
        lightsEl.innerHTML = '';
        const COLORS = ['#ff0044','#ff8800','#ffee00','#00ff88','#00ccff','#cc44ff','#ff44aa'];
        for (let i = 0; i < 12; i++) {
            const beam = document.createElement('div');
            beam.className = 'disco-beam';
            const color = COLORS[i % COLORS.length];
            beam.style.cssText = `
                background: radial-gradient(ellipse at top, ${color}, transparent 70%);
                left: ${(i / 12) * 100}%;
                --dur: ${0.8 + Math.random() * 0.9}s;
                --from: ${-25 - Math.random() * 20}deg;
                --to:   ${ 25 + Math.random() * 20}deg;
                animation-delay: ${Math.random() * -1}s;
            `;
            lightsEl.appendChild(beam);
        }

        // Play Caramelldansen
        if (music) {
            music.currentTime = 0;
            music.volume = 0.7;
            music.play().catch(() => {});
        }

        el.classList.remove('hidden');

        // Flash board cells behind the overlay
        flashBoardDisco();

        // Auto-dismiss or wait for button
        const dismiss = () => {
            el.classList.add('hidden');
            lightsEl.innerHTML = '';
            clearTimeout(_deathMusicTimer);
            if (music) {
                // Fade out
                let v = music.volume;
                const fade = setInterval(() => {
                    v = Math.max(0, v - 0.07);
                    music.volume = v;
                    if (v <= 0) { clearInterval(fade); music.pause(); music.volume = 0.7; }
                }, 60);
            }
            btn.removeEventListener('click', dismiss);
            if (onDone) onDone();
        };

        btn.addEventListener('click', dismiss);

        // Auto-continue after 4s for non-game-over (life loss)
        if (!isGameOver) {
            _deathMusicTimer = setTimeout(dismiss, 4000);
        }
    }

    function flashBoardDisco() {
        // Briefly tint all board cells with rainbow flicker
        const cells = board.querySelectorAll('.cell');
        cells.forEach((c, i) => {
            c.classList.add('disco-grid-cell');
            c.style.setProperty('--cf-dur',   `${0.3 + Math.random() * 0.4}s`);
            c.style.setProperty('--cf-delay', `${Math.random() * -0.5}s`);
        });
        setTimeout(() => {
            cells.forEach(c => {
                c.classList.remove('disco-grid-cell');
                c.style.removeProperty('--cf-dur');
                c.style.removeProperty('--cf-delay');
            });
        }, 4500);
    }

    return {
        toast, flashBorder, updateHUD, updateBossHud,
        showMapTransition, showBossIntro, drawBoard,
        showDeathScreen,
    };
})();
