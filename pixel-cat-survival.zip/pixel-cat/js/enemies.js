/* ══════════════════════════════════════════
   enemies.js — Enemy spawning & movement AI
   ══════════════════════════════════════════ */

const Enemies = (() => {
    const SIZE = Maps.SIZE;

    /* Corner spawn positions */
    const SPAWN_CORNERS = [
        {x:0,y:0},{x:15,y:0},{x:0,y:15},{x:15,y:15},
        {x:0,y:7},{x:15,y:7},{x:7,y:0},{x:7,y:15},
    ];

    function safeSpawn(mapIndex, catX, catY, existingEnemies) {
        for (const pos of SPAWN_CORNERS) {
            if (
                !Maps.isWall(mapIndex, pos.x, pos.y) &&
                !(pos.x === catX && pos.y === catY) &&
                !existingEnemies.some(e => e.x === pos.x && e.y === pos.y)
            ) {
                return { ...pos, hp: 1, maxHp: 1, stunned: false };
            }
        }
        return { x: 0, y: 0, hp: 1, maxHp: 1, stunned: false };
    }

    /** Spawn initial enemies for a map */
    function spawnForMap(mapIndex, catX, catY) {
        const cfg = Maps.get(mapIndex).enemyConfig;
        const enemies = [];
        for (let i = 0; i < cfg.count; i++) {
            enemies.push(safeSpawn(mapIndex, catX, catY, enemies));
        }
        return enemies;
    }

    /** Add an extra enemy on milestone score */
    function addEnemy(mapIndex, catX, catY, enemies) {
        enemies.push(safeSpawn(mapIndex, catX, catY, enemies));
    }

    /** Move all enemies toward player (Manhattan pathfinding) */
    function moveAll(mapIndex, enemies, catX, catY) {
        enemies.forEach(enemy => {
            if (enemy.stunned) return;
            const dx = catX - enemy.x;
            const dy = catY - enemy.y;

            const tryMove = (nx, ny) => {
                if (nx < 0 || nx >= SIZE || ny < 0 || ny >= SIZE) return false;
                if (Maps.isWall(mapIndex, nx, ny)) return false;
                // Don't stack on another enemy
                if (enemies.some(e => e !== enemy && e.x === nx && e.y === ny)) return false;
                enemy.x = nx;
                enemy.y = ny;
                return true;
            };

            if (Math.abs(dx) > Math.abs(dy)) {
                if (!tryMove(enemy.x + (dx > 0 ? 1 : -1), enemy.y))
                    tryMove(enemy.x, enemy.y + (dy > 0 ? 1 : -1));
            } else {
                if (!tryMove(enemy.x, enemy.y + (dy > 0 ? 1 : -1)))
                    tryMove(enemy.x + (dx > 0 ? 1 : -1), enemy.y);
            }
        });
    }

    /** Returns enemy at position or null */
    function at(enemies, x, y) {
        return enemies.find(e => e.x === x && e.y === y) || null;
    }

    /** Stun all enemies for ms milliseconds */
    function stunAll(enemies, ms) {
        enemies.forEach(e => {
            e.stunned = true;
            clearTimeout(e._stunTimer);
            e._stunTimer = setTimeout(() => { e.stunned = false; }, ms);
        });
    }

    /** Deal damage to enemy at position; returns true if killed */
    function damageAt(enemies, x, y, dmg) {
        const e = at(enemies, x, y);
        if (!e) return false;
        e.hp -= dmg;
        if (e.hp <= 0) {
            const idx = enemies.indexOf(e);
            if (idx > -1) enemies.splice(idx, 1);
            return true;
        }
        return false;
    }

    return { spawnForMap, addEnemy, moveAll, at, stunAll, damageAt };
})();
