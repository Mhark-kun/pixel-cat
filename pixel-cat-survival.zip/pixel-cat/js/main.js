/* ══════════════════════════════════════════
   main.js — Input wiring & boot sequence
   ══════════════════════════════════════════ */

(function () {

    /* ── SHOW/HIDE CONTINUE BUTTON ── */
    if (Save.exists()) {
        const btn = document.getElementById('btnContinue');
        btn.style.display = '';
        const data = Save.load();
        if (data) {
            btn.textContent = `⚡ CONTINUE  (${Save.formatDate(data.ts)})`;
        }
    }

    /* ── KEYBOARD ── */
    const PREVENT = new Set([
        'ArrowUp','ArrowDown','ArrowLeft','ArrowRight',
        ' ','w','a','s','d','W','A','S','D'
    ]);

    document.addEventListener('keydown', e => {
        if (PREVENT.has(e.key)) e.preventDefault();

        // Wake AudioContext on first key
        Audio.resume();

        const S = Game.getState();

        // If any overlay open (not start), let buttons handle it
        const shopOpen = !document.getElementById('shopMenu').classList.contains('hidden');
        const invOpen  = !document.getElementById('inventoryMenu').classList.contains('hidden');
        if (shopOpen || invOpen) return;

        // Pause
        if (e.key === 'Escape' && S.gameStarted && !S.gameOver) {
            Game.pause();
            return;
        }

        if (!S.gameStarted || S.gameOver) return;

        switch (e.key) {
            case 'ArrowUp':   case 'w': case 'W': Game.setDirection('up');    break;
            case 'ArrowDown': case 's': case 'S': Game.setDirection('down');  break;
            case 'ArrowLeft': case 'a': case 'A': Game.setDirection('left');  break;
            case 'ArrowRight':case 'd': case 'D': Game.setDirection('right'); break;
            case ' ':                              Game.activateGhost();       break;
            case 'i': case 'I': Inventory.open(S); break;
            case 'b': case 'B':
                S.paused = true;
                Shop.open(S);
                break;
            case 'F5':
                e.preventDefault();
                Game.saveGame();
                break;
            case 'q': case 'Q':
                Inventory.quickUse(S);
                break;
        }
    });

    /* ── MENU BUTTONS ── */
    document.getElementById('btnNewGame').addEventListener('click', () => {
        Audio.resume();
        Save.clear();
        document.getElementById('startMenu').classList.add('hidden');
        Game.newGame();
    });

    document.getElementById('btnContinue').addEventListener('click', () => {
        Audio.resume();
        document.getElementById('startMenu').classList.add('hidden');
        if (!Game.loadGame()) {
            UI.toast('No save found.');
            document.getElementById('startMenu').classList.remove('hidden');
        }
    });

    document.getElementById('btnResume').addEventListener('click', () => {
        Game.pause();
    });

    document.getElementById('btnSave').addEventListener('click', () => {
        Game.saveGame();
        Game.pause(); // close pause menu
    });

    document.getElementById('btnQuit').addEventListener('click', () => {
        document.getElementById('pauseMenu').classList.add('hidden');
        Game.getState().paused = false;
        Game.getState().gameStarted = false;
        Save.clear();
        document.getElementById('startMenu').classList.remove('hidden');
    });

    document.getElementById('btnCloseInv').addEventListener('click', () => {
        Inventory.close();
    });

    document.getElementById('btnCloseShop').addEventListener('click', () => {
        Shop.close();
        // un-pause when shop closes
        const S = Game.getState();
        if (S.paused) S.paused = false;
    });

    /* ── MOBILE CONTROLS ── */
    function bindTouch(id, action) {
        const btn = document.getElementById(id);
        if (!btn) return;
        const handler = e => {
            e.preventDefault();
            Audio.resume();
            action();
        };
        btn.addEventListener('touchstart', handler, { passive: false });
        btn.addEventListener('mousedown',  handler);
    }

    bindTouch('upBtn',    () => Game.setDirection('up'));
    bindTouch('downBtn',  () => Game.setDirection('down'));
    bindTouch('leftBtn',  () => Game.setDirection('left'));
    bindTouch('rightBtn', () => Game.setDirection('right'));
    bindTouch('ghostBtn', () => Game.activateGhost());
    bindTouch('useItemBtn', () => {
        const S = Game.getState();
        if (S.gameStarted) Inventory.quickUse(S);
    });

    bindTouch('btnInvM', () => {
        const S = Game.getState();
        if (S.gameStarted) Inventory.open(S);
    });

    bindTouch('btnShopM', () => {
        const S = Game.getState();
        if (S.gameStarted) {
            S.paused = true;
            Shop.open(S);
        }
    });

    /* ── DRAW INITIAL TITLE BOARD ── */
    // Show a static board on the start screen
    const initialState = {
        mapIndex: 0, catX: 8, catY: 8,
        starX: 4, starY: 4,
        enemies: [{x:1,y:1,stunned:false},{x:14,y:14,stunned:false}],
        abilityActive: false, playerFrozen: false,
        inventory: Items.createInventory(),
        equippedArmor: null, equippedWeapon: null,
        lives: 3, hp: 100, maxHp: 100,
        score: 0, coins: 0, power: 0, highScore: Save.getHigh(),
        floor: 1,
    };
    UI.drawBoard(initialState);

})();
