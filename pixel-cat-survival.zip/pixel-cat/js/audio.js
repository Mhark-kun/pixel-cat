/* ══════════════════════════════════════════
   audio.js — Web Audio API sound engine
   ══════════════════════════════════════════ */

const Audio = (() => {
    let ctx = null;

    function getCtx() {
        if (!ctx) ctx = new (window.AudioContext || window.webkitAudioContext)();
        return ctx;
    }

    function resume() {
        try { if (ctx && ctx.state === 'suspended') ctx.resume(); } catch(e) {}
    }

    function tone(freq, type, dur, vol = 0.15, delay = 0) {
        try {
            const c   = getCtx();
            const osc = c.createOscillator();
            const g   = c.createGain();
            osc.connect(g);
            g.connect(c.destination);
            osc.type = type;
            osc.frequency.setValueAtTime(freq, c.currentTime + delay);
            g.gain.setValueAtTime(vol, c.currentTime + delay);
            g.gain.exponentialRampToValueAtTime(0.001, c.currentTime + delay + dur);
            osc.start(c.currentTime + delay);
            osc.stop(c.currentTime + delay + dur);
        } catch(e) {}
    }

    return {
        resume,
        coin()   { tone(880,'square',0.1); tone(1200,'square',0.09,0.12,0.07); },
        death()  { tone(200,'sawtooth',0.08); tone(120,'sawtooth',0.22,0.14,0.05); },
        ghost()  { tone(440,'sine',0.3,0.1); tone(660,'sine',0.25,0.08,0.15); },
        hurt()   { tone(160,'sawtooth',0.12,0.18); },
        heal()   { tone(660,'sine',0.1); tone(880,'sine',0.12,0.1,0.1); },
        buy()    { tone(700,'square',0.08); tone(900,'square',0.1,0.1,0.09); },
        boss()   { tone(80,'sawtooth',0.5,0.2); tone(120,'sawtooth',0.3,0.16,0.3); },
        portal() { tone(500,'sine',0.15); tone(800,'sine',0.15,0.1,0.1); tone(1100,'sine',0.1,0.08,0.2); },
        levelUp(){ tone(523,'square',0.08); tone(659,'square',0.08,0.1,0.1); tone(784,'square',0.15,0.12,0.2); },
        save()   { tone(600,'sine',0.07); tone(750,'sine',0.09,0.1,0.08); },
    };
})();
