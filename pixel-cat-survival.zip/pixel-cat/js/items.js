/* ══════════════════════════════════════════
   items.js — Item definitions & inventory
   ══════════════════════════════════════════ */

const Items = (() => {

    /* ── ITEM CATALOG ── */
    const CATALOG = {
        // ── CONSUMABLES ──
        potion_sm: {
            id: 'potion_sm', emoji: '🧪', name: 'SMALL POTION',
            desc: 'Restores 25 HP.', type: 'consumable',
            effect: state => { state.hp = Math.min(state.maxHp, state.hp + 25); },
            price: 15, dropWeight: 20,
        },
        potion_lg: {
            id: 'potion_lg', emoji: '💊', name: 'LARGE POTION',
            desc: 'Restores 60 HP.', type: 'consumable',
            effect: state => { state.hp = Math.min(state.maxHp, state.hp + 60); },
            price: 35, dropWeight: 8,
        },
        elixir: {
            id: 'elixir', emoji: '✨', name: 'ELIXIR',
            desc: 'Full HP restore + +1 life.', type: 'consumable',
            effect: state => { state.hp = state.maxHp; state.lives = Math.min(state.lives + 1, 9); },
            price: 80, dropWeight: 3,
        },
        speed_pill: {
            id: 'speed_pill', emoji: '⚡', name: 'SPEED PILL',
            desc: 'Max ghost power instantly.', type: 'consumable',
            effect: state => { state.power = 5; },
            price: 25, dropWeight: 10,
        },
        bomb: {
            id: 'bomb', emoji: '💣', name: 'BOMB',
            desc: 'Stuns all enemies for 3s.', type: 'consumable',
            effect: state => { state.stunEnemies(3000); },
            price: 30, dropWeight: 8,
        },
        magnet: {
            id: 'magnet', emoji: '🧲', name: 'COIN MAGNET',
            desc: '+5 coins instantly.', type: 'consumable',
            effect: state => { state.coins += 5; },
            price: 10, dropWeight: 15,
        },

        // ── ARMOR (equipment) ──
        armor_leather: {
            id: 'armor_leather', emoji: '🥋', name: 'LEATHER VEST',
            desc: '+20 max HP.', type: 'armor',
            stat: { maxHp: 20 },
            price: 40, dropWeight: 6,
        },
        armor_chain: {
            id: 'armor_chain', emoji: '🛡', name: 'CHAIN MAIL',
            desc: '+40 max HP, absorb 1 hit.', type: 'armor',
            stat: { maxHp: 40, shield: 1 },
            price: 75, dropWeight: 3,
        },
        armor_dragon: {
            id: 'armor_dragon', emoji: '🐉', name: 'DRAGON SCALE',
            desc: '+80 max HP, absorb 2 hits.', type: 'armor',
            stat: { maxHp: 80, shield: 2 },
            price: 150, dropWeight: 1,
        },

        // ── WEAPONS ──
        sword: {
            id: 'sword', emoji: '⚔️', name: 'IRON SWORD',
            desc: 'Deal 1 damage to nearby enemies.', type: 'weapon',
            stat: { attack: 1 },
            price: 50, dropWeight: 5,
        },
        laser: {
            id: 'laser', emoji: '🔫', name: 'LASER GUN',
            desc: 'Deal 2 damage to nearby enemies.', type: 'weapon',
            stat: { attack: 2 },
            price: 90, dropWeight: 2,
        },
    };

    /* ── BUILD SHOP STOCK (per map) ── */
    function shopStock(mapIndex) {
        // Later maps unlock better items
        const tiers = [
            ['potion_sm','potion_lg','speed_pill','bomb','magnet'],
            ['potion_sm','potion_lg','elixir','bomb','armor_leather'],
            ['potion_lg','elixir','speed_pill','bomb','armor_leather','sword'],
            ['potion_lg','elixir','bomb','armor_chain','sword','laser'],
            ['elixir','armor_chain','armor_dragon','sword','laser','speed_pill'],
        ];
        const idx = Math.min(mapIndex, tiers.length - 1);
        return tiers[idx].map(id => CATALOG[id]);
    }

    /* ── RANDOM DROP on star pickup ── */
    function randomDrop(mapIndex) {
        // 30% chance of drop, weighted by dropWeight
        if (Math.random() > 0.30) return null;
        const pool = Object.values(CATALOG).filter(it => it.dropWeight);
        const totalWeight = pool.reduce((s, it) => s + it.dropWeight, 0);
        let r = Math.random() * totalWeight;
        for (const item of pool) {
            r -= item.dropWeight;
            if (r <= 0) return item.id;
        }
        return null;
    }

    /* ── INVENTORY OBJ ── */
    function createInventory() {
        return {
            // { id: count } for consumables; true/false for equipment
            slots: {},

            add(id) {
                const item = CATALOG[id];
                if (!item) return false;
                if (item.type === 'consumable') {
                    this.slots[id] = (this.slots[id] || 0) + 1;
                } else {
                    this.slots[id] = (this.slots[id] || 0) + 1;
                }
                return true;
            },

            remove(id) {
                if (!this.slots[id]) return false;
                this.slots[id]--;
                if (this.slots[id] <= 0) delete this.slots[id];
                return true;
            },

            count(id) { return this.slots[id] || 0; },

            has(id) { return !!this.slots[id]; },

            list() {
                return Object.entries(this.slots)
                    .filter(([,q]) => q > 0)
                    .map(([id, qty]) => ({ ...CATALOG[id], qty }));
            },
        };
    }

    return { CATALOG, shopStock, randomDrop, createInventory };
})();
